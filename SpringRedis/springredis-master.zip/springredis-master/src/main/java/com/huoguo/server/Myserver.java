package com.huoguo.server;

import com.huoguo.bean.User;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;


@Service
public class Myserver {
    @Cacheable(value = "cacheA")
    public User getUserByAgeAndName(String name,int age){
        return new User(name,age,System.currentTimeMillis());
    }
    @Cacheable(value = "cacheB")
    public User getUserByName(String name){
        User u=new User();
        u.setName(name);
        u.setCreatTime(System.currentTimeMillis());
        return u;
    }
    @CacheEvict(value = {"cacheA","cacheB"},allEntries = true)
    public void clearCache(){
        System.out.println("clear over");
    }
}
