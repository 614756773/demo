import com.huoguo.bean.User;
import com.huoguo.server.Myserver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) throws InterruptedException {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
        Myserver myserver= (Myserver) ctx.getBean("myserver");
        User u =myserver.getUserByName("大白");
        Thread.sleep(2000);
        User u2=myserver.getUserByName("大白");
        System.out.println(u);
        System.out.println(u2);
        System.out.println(u==u2);
    }
}
