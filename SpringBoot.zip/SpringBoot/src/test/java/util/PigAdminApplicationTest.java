package util;

import com.huoguo.Application;
import org.jasypt.encryption.StringEncryptor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class)
public class PigAdminApplicationTest {
    @Autowired
    private StringEncryptor stringEncryptor;

    @Test
    public void testjasyptEncrypt() {
        // 要启动该测试请
        // ①请在VM option中设置 -Djasypt.encryptor.password={你的根密码}
        // ②或者在配置文件里添加上jasypt.encryptor.password={你的根密码}
        System.out.println(String.format("加密【123456】后的密码为：【%s】", stringEncryptor.encrypt("123456")));
    }


//    @Value("${spring.datasource.password}")
//    private String password;
//    @Test
//    public void testjasyptDcrypt() throws IllegalAccessException, InstantiationException {
//        System.out.println(String.format("解密后的密码：【%s】", password));
//    }

}