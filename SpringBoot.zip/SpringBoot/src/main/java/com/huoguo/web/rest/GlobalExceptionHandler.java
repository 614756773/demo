package com.huoguo.web.rest;

import com.huoguo.service.dto.ResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ResponseDTO<String> jsonErrorHandler(HttpServletRequest request, Exception e) {
        ResponseDTO<String> responseDTO = new ResponseDTO<>();
        responseDTO.setMessage(e.getMessage());
        responseDTO.setCode(HttpStatus.BAD_GATEWAY.value());
        responseDTO.setData("something wrong");
        responseDTO.setUrl(request.getRequestURL().toString());
        return responseDTO;
    }
}
